# My 5 Shortcuts — rozszerzenie PopClip

Rozszerzenie dodaje **5 przycisków** (z ikonami 1–5) w pasku PopClip. Każdy przycisk wysyła **skrót klawiszowy**, który definiujesz w ustawieniach. Dla każdego przycisku możesz też wybrać **ikonę** z dużej listy (kopiuj, nożyczki, zrzut ekranu, OCR, nagrywanie, postać mówiąca itd.).

## Instalacja

1. W Finderze **dwuklik** na folderze `CustomShortcuts.popclipext`.
2. PopClip zainstaluje rozszerzenie (może pojawić się ostrzeżenie o niepodpisanej wtyczce – możesz zatwierdzić).
3. W PopClip przejdź do **Actions** (Akcje) i włącz rozszerzenie **„My 5 Shortcuts”**.

## Konfiguracja skrótów i ikon

1. W ustawieniach PopClip: **Actions** → znajdź **„My 5 Shortcuts”** → ikona **zębatki** (opcje).
2. Dla każdego przycisku (1–5) ustaw:
   - **Skrót** — kombinacja klawiszy (np. `command b`, `option shift s`).
   - **Ikona** — wybór z listy (cyfry, kopiuj, nożyczki, zrzut ekranu, OCR, nagrywanie, dymek mówienia itd.).
3. Format skrótów:
   - `command b` — ⌘B  
   - `command shift i` — ⌘⇧I  
   - `option space` — ⌥Spacja  
   - `control option command x` — ⌃⌥⌘X  

**Modifikatory:** `command`, `option`, `control`, `shift` (można łączyć).  
**Klawisze:** litera (np. `b`), `return`, `space`, `escape`, `delete`, `tab`, strzałki, F1–F20 itd.

## Użycie

Zaznacz dowolny tekst → pojawi się pasek PopClip z przyciskami 1–5 → wybierz przycisk, żeby „wcisnąć” przypisany skrót w aktywnym programie.

---

**English:** [README-EN.md](README-EN.md)

Źródło: [PopClip Extensions Developer Reference](https://www.popclip.app/dev/)
